package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * <p>
 * Title: TeamScreen
 * </p>
 *
 * <p>
  * Description: The Della Team Screen code
* </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * @version 1.00
 * Many thanks to Harry Sameshima for his original work.
 * 
 * @ModifiedAuthor Bibek Kr. Sah
 * @version 2.00
 * Updated the functionality.
 * 
 */
public class TeamScreen extends JPanel {
	
	private final String Team_REPO = "TeamsData.txt";
	private final String MEMBERS_REPO = "MembersData.txt";
	
	//---------------------------------------------------------------------------------------------------------------------
	// Team Screen constants

	//---------------------------------------------------------------------------------------------------------------------
	// Team Screen attributes

	//---------------------------------------------------------------------------------------------------------------------
	// Team Screen GUI elements
	JLabel teamLabel = new JLabel();
	JLabel TeamName = new JLabel();
	JTextField TnameTextField = new JTextField();
	
	private DefaultListModel<String> listModel = new DefaultListModel<>();
	
	JList<String> TeamDellaList = new JList();
	
	JLabel InfoAddName = new JLabel();
	JLabel InfoAddName1 = new JLabel();
	JLabel InfoAddName2 = new JLabel();
	JLabel InfoAddName3 = new JLabel();
	
	JLabel InfoRemoveName = new JLabel();
	JLabel InfoRemoveName1 = new JLabel();
	JLabel InfoRemoveName2 = new JLabel();
	
	JLabel InfoAddAssociation = new JLabel();
	JLabel InfoAddAssociation1 = new JLabel(); 
	JLabel InfoAddAssociation2 = new JLabel();
	JLabel InfoAddAssociation3 = new JLabel();
	
	JLabel InfoRemoveAssociation = new JLabel();
	
	JLabel AvailableMember = new JLabel();
	JLabel AvailableMemberName = new JLabel();
	DefaultListModel<String> avaAFFModel = new DefaultListModel<>();
	JList<String> AvailableMemberList = new JList<String>(avaAFFModel);
	
	JLabel CurrentMember = new JLabel();
	JLabel CurrentMemberName = new JLabel();
	DefaultListModel<String> curAFFModel = new DefaultListModel<>();
	JList<String> CurrentMemberList = new JList<String>(curAFFModel);
	
	JButton AddToListButton = new JButton();
	ActionListener AddToListActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			String name = TnameTextField.getText().toString();
			if (!name.isEmpty()) {
				listModel.addElement(name);
				saveTeamInRepo(name);
			} 
		}
	};
	
	JButton RemoveFromListButton = new JButton();
	ActionListener RemoveFromListListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			remove();
		}
	};
	
	JButton AddAssociationButton = new JButton();
	ActionListener AddAssociationButtonListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			String val = AvailableMemberList.getSelectedValue();
			curAFFModel.addElement(val);
			avaAFFModel.removeElement(val);
		}
	};
	
	JButton RemoveAssociationButton = new JButton();
	ActionListener RemoveAssociationButtonListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			String val = CurrentMemberList.getSelectedValue();
			avaAFFModel.addElement(val);
			curAFFModel.removeElement(val);
		}
	};
	
	
	
	
	
//	JButton AddAssociationButton = new JButton();
//	JButton RemoveAssociationButton = new JButton();
	
	JLabel Instr = new JLabel();
	
	ImageIcon removeicon = new ImageIcon("remove.png");
	
	JLabel TeamsDella = new JLabel();
	
	
	public TeamScreen() {
		// Set up all of the Graphical User Interface elements and place them on the screen
		guiInit();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the layout.
	 * 
	 */
	private void guiInit() {
		// Set all of the graphical elements in this screen by adding them to the layout
		this.setLayout(null);

		teamLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		teamLabel.setBorder(BorderFactory.createEtchedBorder());
		teamLabel.setHorizontalAlignment(SwingConstants.CENTER);
		teamLabel.setText("Teams");
		teamLabel.setBounds(new Rectangle(0, 0, 657, 20));

		TeamName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		TeamName.setText("Name of a new team");
		TeamName.setBounds(new Rectangle(3, 35, 400, 15));
		
		TnameTextField.setText("");
		TnameTextField.setBounds(new Rectangle(3, 50, 230, 22));
						
		InfoAddName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName.setText("To add a name to the list:");
		InfoAddName.setBounds(new Rectangle(3, 75, 240, 15));
		
		InfoAddName1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName1.setText("1. Click on the box above.");
		InfoAddName1.setBounds(new Rectangle(3, 90, 240, 15));
		
		InfoAddName2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName2.setText("2. Type the name.");
		InfoAddName2.setBounds(new Rectangle(3, 105, 240, 15));
		
		InfoAddName3.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName3.setText("3. Click the ''Add to List'' button.");
		InfoAddName3.setBounds(new Rectangle(3, 120, 240, 15));
		
		InfoRemoveName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName.setText("To remove a name from the list:");
		InfoRemoveName.setBounds(new Rectangle(3, 140, 240, 15));
		
		InfoRemoveName1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName1.setText("1. Click on the name to remove.");
		InfoRemoveName1.setBounds(new Rectangle(3, 155, 240, 15));
		
		InfoRemoveName2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName2.setText("2. Click the ''Remove from List'' button.");
		InfoRemoveName2.setBounds(new Rectangle(3, 170, 240, 15));
						
		AddToListButton.setFont(new Font("Dialog", Font.BOLD, 12));
		AddToListButton.setBounds(new Rectangle(240, 70, 170, 30));
		AddToListButton.setText("Add to List ->");
		
		RemoveFromListButton.setFont(new Font("Dialog", Font.BOLD, 12));
		RemoveFromListButton.setBounds(new Rectangle(240, 120, 170, 30));
		RemoveFromListButton.setText("<- Remove from List");
				
		AddAssociationButton.setFont(new Font("Dialog", Font.BOLD, 12));
		AddAssociationButton.setBounds(new Rectangle(240, 325, 170, 30));
		AddAssociationButton.setText("Add Association ->");
		AddAssociationButton.addActionListener(AddAssociationButtonListener);
		
		RemoveAssociationButton.setFont(new Font("Dialog", Font.BOLD, 12));
		RemoveAssociationButton.setBounds(new Rectangle(240, 375, 170, 30));
		RemoveAssociationButton.setText("<- Remove Association");
		RemoveAssociationButton.addActionListener(RemoveAssociationButtonListener);
		
		Instr.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		Instr.setText("<HTML><Body>Click on an team's name <BR/> to see team associations.</BODY></HTML>");
		Instr.setBounds(new Rectangle(240, 160, 240, 40));
				
		TeamsDella.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		TeamsDella.setText("Teams known by Della");
		TeamsDella.setBounds(new Rectangle(450, 30, 657, 20));
		
		TeamDellaList.setToolTipText("");
		TeamDellaList.setBounds(new Rectangle(450, 50, 175, 140));
						
		InfoAddAssociation.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAssociation.setText("To add a team association for a team:");
		InfoAddAssociation.setBounds(new Rectangle(3, 200, 240, 15));
		
		InfoAddAssociation1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAssociation1.setText("1. Click on the name of the team above right.");
		InfoAddAssociation1.setBounds(new Rectangle(4, 215, 280, 15));
		
		InfoAddAssociation2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAssociation2.setText("2. Click on a member name in the list below.");
		InfoAddAssociation2.setBounds(new Rectangle(4, 230, 240, 15));
		
		InfoAddAssociation3.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAssociation3.setText("3. Click on 'Add Association' button.");
		InfoAddAssociation3.setBounds(new Rectangle(4, 245, 240, 15));
		
		InfoRemoveAssociation.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveAssociation.setText("<HTML><BODY> To remove a member association for a team: "
				+ "<br/> 1. Click on the name of the team above. "
				+ "<br/> 2. Click on a member name in the list below. "
				+ "<br/> 3. Click on ''Remove Association'' button.");
		InfoRemoveAssociation.setBounds(new Rectangle(365, 190, 260, 80));
		 
		AvailableMember.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		AvailableMember.setText("Available members for team");
		AvailableMember.setBounds(new Rectangle(5, 270, 240, 15));
		
		AvailableMemberName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		AvailableMemberName.setText("");
		AvailableMemberName.setBounds(new Rectangle(5, 285, 240, 15));
		
		AvailableMemberList.setToolTipText("");
		AvailableMemberList.setBounds(new Rectangle(5, 300, 175, 140));
		
		CurrentMember.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		CurrentMember.setText("Current member for team");
		CurrentMember.setBounds(new Rectangle(450, 270, 240, 15));
		
		CurrentMemberName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		CurrentMemberName.setText("");
		CurrentMemberName.setBounds(new Rectangle(450, 285, 240, 15));
		
		CurrentMemberList.setToolTipText("");
		CurrentMemberList.setBounds(new Rectangle(450, 300, 175, 140));
				
		//----------------------------------------------------------------------------
		// Add the objects to the layout
		this.add(teamLabel);
		this.add(TeamName);	
		this.add(TnameTextField);
		this.add(InfoAddName);
		this.add(InfoAddName1);
		this.add(InfoAddName2);
		this.add(InfoAddName3);
		this.add(InfoRemoveName);
		this.add(InfoRemoveName1);
		this.add(InfoRemoveName2);
		this.add(InfoAddAssociation);
		this.add(InfoAddAssociation1);
		this.add(InfoAddAssociation2);
		this.add(InfoAddAssociation3);
		this.add(InfoRemoveAssociation);
		this.add(AddToListButton);
		
		AddToListButton.addActionListener(AddToListActionListner);
		RemoveFromListButton.addActionListener(RemoveFromListListener);
		
		this.add(RemoveFromListButton);
		this.add(Instr);
		this.add(TeamsDella);
		this.add(TeamDellaList);
//		this.add(removeicon);
		this.add(AvailableMember);
		this.add(AvailableMemberName);
		this.add(AvailableMemberList);
		this.add(AddAssociationButton);
		this.add(RemoveAssociationButton);
		this.add(CurrentMember);
		this.add(CurrentMemberName);
		this.add(CurrentMemberList);
		
		TeamDellaList.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				getAllNameFromRepoMember();
			}
		});

		AddToListButton.addActionListener(AddToListActionListner);
		RemoveFromListButton.addActionListener(RemoveFromListListener);

		ListSelectionListener listBoxListSelectionListener = new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				AvailableMemberName.setText(TeamDellaList.getSelectedValue());
				CurrentMemberName.setText(TeamDellaList.getSelectedValue());
			}
		};
		TeamDellaList.addListSelectionListener(listBoxListSelectionListener);

		TeamDellaList.setModel(listModel);
		getAllNameFromRepo();
		
		TeamDellaList.setModel(listModel);
		getAllNameFromRepo();
		
//		ListSelectionListener listBoxListSelectionListener = new ListSelectionListener() {
//			@Override
//			public void valueChanged(ListSelectionEvent e) {
//				AvailableMemberName.setText(TeamDellaList.getSelectedValue());
//				CurrentMemberName.setText(TeamDellaList.getSelectedValue());
//			}
//		};
//		TeamDellaList.addListSelectionListener(listBoxListSelectionListener);
	}
		
	private void saveTeamInRepo(String name) {
		File file = new File(Team_REPO);

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try {
			FileWriter writer = new FileWriter(file, true);
			writer.write(name + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
		
	
	
	
//	private void saveTeamInRepo(String name) {
//		File file = new File(Team_REPO);
//	    try {
//	      if (!file.exists()) {
//	        file.createNewFile();
//	      }
//	      FileWriter writer = new FileWriter(file, true);
//	      writer.write(name + "\n");
//	      writer.close();
//	    } catch (Exception e) {
//	      e.printStackTrace();
//	    }
//	}
	
	private void getAllNameFromRepo() {
		File file = new File(Team_REPO);
		if (file.exists()) {
			try {
				Scanner scanner = new Scanner(file);
				System.out.println(scanner.hasNextLine());
				while (scanner.hasNextLine()) {
					String name = scanner.nextLine();
					listModel.addElement(name);
				}
				scanner.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("File does not exists!");
		}
	}
	
	private void remove() {
		String memberToRemove = listModel.get(TeamDellaList.getSelectedIndex());
		listModel.remove(TeamDellaList.getSelectedIndex());

		File file = new File(Team_REPO);
		File tempFile = new File("temp_team_repo.txt");

		if (file.exists()) {
			try {
				FileWriter writer = new FileWriter(tempFile);

				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String member = scanner.nextLine();
					if (!member.equals(memberToRemove)) {
						writer.write(member + "\n");
					}
				}
				scanner.close();
				writer.close();
				file.delete();
				tempFile.renameTo(new File(Team_REPO));
			} 
			catch (Exception e) {}
		}
	}
	
	private void getAllNameFromRepoMember() {
		avaAFFModel.clear();
		File file = new File(MEMBERS_REPO);
		if (file.exists()) {
			try {
				Scanner scanner = new Scanner(file);

				while (scanner.hasNextLine()) {
					String name = scanner.nextLine();
					avaAFFModel.addElement(name);
				}
				scanner.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else {

		}
	}

}
