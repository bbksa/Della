package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import control.Controller;
import model.ActionItem;
import model.ActionItemManager;
import persistence.DataManager;

/**
 * <p>
 * Title: ConsoleScreen
 * </p>
 *
 * <p>
 * Description:  A manually generated action item screen for Della
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * Many thanks to Harry Sameshima for his original work.
 * @version 1.00
 * 
 * @ModifiedAuthor Bibek Kr. Sah
 * Updated the functionality.
 * @version 2.00
 * 
 */
public class ConsoleScreen extends JPanel {

	private static HashMap<String, ActionItem> staticActionItems;

	private DefaultListModel<String> listModel = new DefaultListModel<>();

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen constants

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen attributes

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen GUI elements
	JLabel consoleLabel = new JLabel();

	JLabel copyrightLabel = new JLabel();
	//---------------------------------------------------------------------------------------------------------------------

	private Boolean updatingGUI = false;
	private Controller theController = null;
	private ActionItemManager aiM = null;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	JLabel actionitems = new JLabel();

	JLabel sortingDirection = new JLabel();
	JComboBox SortingDirectionComboBox = new JComboBox(ActionItemManager.sortingdirectionStrings);

	JLabel sortingDirection1 = new JLabel();
	JComboBox SortingDirection1ComboBox = new JComboBox(ActionItemManager.sortingdirection1Strings);

	JLabel sortingDirection2 = new JLabel();
	JComboBox SortingDirection2ComboBox = new JComboBox(ActionItemManager.sortingdirection2Strings);
	
	JLabel InclusionFactor = new JLabel();
	JComboBox InclusionFactorComboBox = new JComboBox(ActionItemManager.InclusionFactorStrings);

	JLabel selectedLabel = new JLabel();
	JLabel nameLabel = new JLabel();
	JLabel nameTextField = new JLabel();
	JLabel descriptionLabel = new JLabel();
	JScrollPane descriptionScrollPane = new JScrollPane();
	JTextArea descriptionTextArea = new JTextArea();
		
	JList ActionItemList;
	
	JLabel resolutionLabel = new JLabel();
	JScrollPane resolutionScrollPane = new JScrollPane();
	JTextArea resolutionTextArea = new JTextArea();

	JLabel unsavedChangesLabel = new JLabel();
	JLabel datesLabel = new JLabel();
	JLabel creationLabel = new JLabel();
	JLabel creationValueLabel = new JLabel();
	JLabel dueDateLabel = new JLabel();
	JTextField dueDateTextField = new JTextField();
	JLabel formatLabel = new JLabel();
	JLabel actionItemLabel2 = new JLabel();
	JLabel statusLabel = new JLabel();
	JLabel statusLabelRepo = new JLabel();
	JLabel assignedMember = new JLabel();
	JLabel assignedMemberRepo = new JLabel();
	JLabel assignedTeam = new JLabel();
	JLabel assignedTeamRepo = new JLabel();
	JComboBox actionItemListConsole = new JComboBox();

	/**
	 * The ConsoleScreen class constructor.
	 * 
	 */
	public ConsoleScreen() {
		// Set up all of the Graphical User Interface elements and position them on the screen
		guiInit();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the loayout.
	 */
	private void guiInit() {
		this.setLayout(null);
		consoleLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		consoleLabel.setBorder(BorderFactory.createEtchedBorder());
		consoleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		consoleLabel.setText("Console");
		consoleLabel.setBounds(new Rectangle(0, 0, 657, 20));

		copyrightLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 10));
		copyrightLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		copyrightLabel.setText("Copyright � 2021 Bibek Kumar Sah");
		copyrightLabel.setBounds(new Rectangle(0, 405, 605, 15));

		actionitems.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionitems.setText("Action Items:");
		actionitems.setBounds(new Rectangle(6, 35, 123, 15));

		ActionItemList = new JList(listModel);
		ActionItemList.setBounds(new Rectangle(6, 50, 430, 90));
		ActionItemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ActionListener listViewActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent ae) {  }
		};
		
		sortingDirection.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		sortingDirection.setText("Sorting Direction:");
		sortingDirection.setBounds(new Rectangle(450, 20, 180, 15));

		SortingDirectionComboBox.setBounds(new Rectangle(450, 35, 180, 25));

		sortingDirection1.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		sortingDirection1.setText("First Sorting Factor:");
		sortingDirection1.setBounds(new Rectangle(450, 60, 180, 15));

		SortingDirection1ComboBox.setBounds(new Rectangle(450, 75, 180, 25));

		sortingDirection2.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		sortingDirection2.setText("Second Sorting Factor:");
		sortingDirection2.setBounds(new Rectangle(450, 100, 180, 15));

		SortingDirection2ComboBox.setBounds(new Rectangle(450, 115, 180, 25));

		InclusionFactor.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		InclusionFactor.setText("Inclusion Factor:");
		InclusionFactor.setBounds(new Rectangle(450, 140, 180, 15));

		InclusionFactorComboBox.setBounds(new Rectangle(450, 155, 180, 25));

		selectedLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		selectedLabel.setText("Selected Action Item:");
		selectedLabel.setBounds(new Rectangle(6, 145, 123, 15));

		nameLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		nameLabel.setText("Name:");
		nameLabel.setBounds(new Rectangle(7, 165, 42, 15));

		nameTextField.setText("");
		nameTextField.setBorder(BorderFactory.createEtchedBorder());
		nameTextField.setBounds(new Rectangle(46, 165, 390, 22));
		
		descriptionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		descriptionLabel.setText("Description:");
		descriptionLabel.setBounds(new Rectangle(6, 190, 69, 15));
		descriptionScrollPane.setBounds(new Rectangle(7, 210, 430, 75));
		descriptionScrollPane.getViewport().add(descriptionTextArea);
		descriptionTextArea.setText("");

		resolutionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		resolutionLabel.setText("Resolution:");
		resolutionLabel.setBounds(new Rectangle(6, 295, 73, 15));
		resolutionScrollPane.setBounds(new Rectangle(7, 315, 430, 75));
		resolutionScrollPane.getViewport().add(resolutionTextArea);
		resolutionTextArea.setToolTipText("");
		resolutionTextArea.setText("");

		datesLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		datesLabel.setText("Dates");
		datesLabel.setBounds(new Rectangle(450, 180, 34, 16));

		creationLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		creationLabel.setText("Creation:");
		creationLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		creationLabel.setBounds(new Rectangle(469, 195, 51, 16));
		creationValueLabel.setText("");
		creationValueLabel.setBounds(new Rectangle(528, 195, 85, 16));

		dueDateLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		dueDateLabel.setText("Due:");
		dueDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		dueDateLabel.setBounds(new Rectangle(469, 217, 51, 16));
		dueDateTextField.setBounds(new Rectangle(524, 215, 90, 20));
		formatLabel.setFont(new java.awt.Font("Dialog", Font.PLAIN, 10));
		formatLabel.setText("Use yyyy-mm-dd format");
		formatLabel.setBounds(new Rectangle(495, 238, 125, 11));

		actionItemLabel2.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel2.setText("Action Item");
		actionItemLabel2.setBounds(new Rectangle(450, 260, 67, 15));

		statusLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		statusLabel.setText("Status:");
		statusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		statusLabel.setBounds(new Rectangle(469, 277, 51, 16));

		statusLabelRepo.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		statusLabelRepo.setText("");
		statusLabelRepo.setHorizontalAlignment(SwingConstants.RIGHT);
		statusLabelRepo.setBounds(new Rectangle(515, 277, 51, 16));
		
		assignedMember.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignedMember.setText("Assigned to Member:");
		assignedMember.setBounds(new Rectangle(450, 300, 200, 15));
		
		assignedMemberRepo.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignedMemberRepo.setText("");
		assignedMemberRepo.setBounds(new Rectangle(460, 315, 200, 15));

		assignedTeam.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignedTeam.setText("Assigned to Team:");
		assignedTeam.setBounds(new Rectangle(450, 345, 200, 15));
		
		assignedTeamRepo.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		assignedTeamRepo.setText("");
		assignedTeamRepo.setBounds(new Rectangle(460, 360, 200, 15));

		unsavedChangesLabel.setFont(new Font("Dialog", Font.BOLD, 12));
		unsavedChangesLabel.setBounds(new Rectangle(250, 430, 200, 15));
		unsavedChangesLabel.setText("");
		unsavedChangesLabel.setForeground(Color.red);

		this.add(consoleLabel);
		this.add(copyrightLabel);

		this.add(actionitems);
		this.add(ActionItemList);
		this.add(sortingDirection);
		this.add(SortingDirectionComboBox);
		this.add(sortingDirection1);
		this.add(SortingDirection1ComboBox);
		this.add(sortingDirection2);
		this.add(SortingDirection2ComboBox);
		this.add(InclusionFactor);
		this.add(InclusionFactorComboBox);
		this.add(selectedLabel);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(descriptionLabel);
		this.add(descriptionScrollPane);
		this.add(resolutionLabel);
		this.add(resolutionScrollPane);

		this.add(datesLabel);
		this.add(creationLabel);
		this.add(creationValueLabel);
		this.add(dueDateLabel);
		this.add(dueDateTextField);
		this.add(formatLabel);
		this.add(actionItemLabel2);
		this.add(statusLabel);
		this.add(statusLabelRepo);
		this.add(assignedMember);
		this.add(assignedMemberRepo);
		this.add(assignedTeam);
		this.add(assignedTeamRepo);
		this.add(unsavedChangesLabel);
		dataforlist();
	}

	private void dataforlist() {
		ActionItemList.removeAll();
		try {
			Controller controller = (Controller) DataManager.readData();
			HashMap<String, ActionItem> actionItemHashMap = controller.getActionItemManager().actionItemHashMap;
			System.out.println(actionItemHashMap.size());

			for (Map.Entry<String, ActionItem> actionItem : actionItemHashMap.entrySet()) {
				listModel.addElement(actionItem.getValue().getActionItemName());
			}
			
			ActionItemList.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent e) {
					String selectedName = (String) ActionItemList.getSelectedValue();
					ActionItem actionItem = actionItemHashMap.get(selectedName.trim());
					fillInfoInWindow(actionItem);
				}
			});
		} catch (NullPointerException e) {
		}
	}

	private void fillInfoInWindow(ActionItem actionItem) {
		if (actionItem == null) {
			System.out.println("null");
			return;
		}
		nameTextField.setText(actionItem.getActionItemName());
		descriptionTextArea.setText(actionItem.getDescription());
		resolutionTextArea.setText(actionItem.getResolution());
		assignedTeamRepo.setText(actionItem.getTeamName());
		assignedMemberRepo.setText(actionItem.getMemberName());
		dueDateTextField.setText(actionItem.getDueDate().toString());
		creationValueLabel.setText(actionItem.getCreatedDate().toString());
		statusLabelRepo.setText(actionItem.getStatus());
	}
}
