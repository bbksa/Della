package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import control.Controller;
import model.ActionItem;
import persistence.DataManager;

/**
 * <p>
 * Title: MemberScreen
 * </p>
 *
 * <p>
 * Description: The Della Member Screen code
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * @version 1.00
 * Many thanks to Harry Sameshima for his original work.
 * 
 * @ModifiedAuthor Bibek Kr. Sah
 * @version 2.00
 * Updated the functionality.
 * 
 */
public class MemberScreen extends JPanel {

	private DefaultListModel<String> listModel = new DefaultListModel<>();

	private final String Team_REPO = "TeamsData.txt";
	private final String MEMBERS_REPO = "MembersData.txt"; 
	private Scanner scanner;

	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen constants

	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen attributes

	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen GUI elements
	JLabel memberLabel = new JLabel();
	JLabel MemberName = new JLabel();
	JTextField MnameTextField = new JTextField();

	JList<String> IndividualDellaList = new JList();

	JLabel InfoAddName = new JLabel();
	JLabel InfoAddName1 = new JLabel();
	JLabel InfoAddName2 = new JLabel();
	JLabel InfoAddName3 = new JLabel();

	JLabel InfoRemoveName = new JLabel();
	JLabel InfoRemoveName1 = new JLabel();
	JLabel InfoRemoveName2 = new JLabel();

	JLabel InfoAddAffiliation = new JLabel();
	JLabel InfoAddAffiliation1 = new JLabel();
	JLabel InfoAddAffiliation2 = new JLabel();
	JLabel InfoAddAffiliation3 = new JLabel();

	JLabel InfoRemoveAffiliation = new JLabel();

	JLabel AvailableTeam = new JLabel();
	JLabel AvailableTeamName = new JLabel();
	
	DefaultListModel<String> avaAFFModel = new DefaultListModel<>();
	JList<String> AvailableTeamList = new JList<String>(avaAFFModel);

	JLabel CurrentTeam = new JLabel();
	JLabel CurrentTeamName = new JLabel();
	
	DefaultListModel<String> curAFFModel = new DefaultListModel<>();
	JList<String> CurrentTeamList = new JList<String>(curAFFModel);

	JButton AddToListButton = new JButton();
	ActionListener AddToListActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			String name = MnameTextField.getText().toString();
			if (!name.isEmpty()) {
				listModel.addElement(name);
				saveMemberInRepo(name);
			} 
		}
	};

	JButton RemoveFromListButton = new JButton();
	ActionListener RemoveFromListListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			remove();
		}
	};
	
	
	
	JButton AddAffiliationButton = new JButton();
	ActionListener AddAffiliationButtonListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			String val = AvailableTeamList.getSelectedValue();
			curAFFModel.addElement(val);
			avaAFFModel.removeElement(val);
		}
	};
	
	JButton RemoveAffiliationButton = new JButton();
	ActionListener RemoveAffiliationButtonListener = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			String val = CurrentTeamList.getSelectedValue();

			avaAFFModel.addElement(val);
			curAFFModel.removeElement(val);
		}
	};
	
	JLabel Instr = new JLabel();

	ImageIcon removeicon = new ImageIcon("remove.png");
	JLabel image = new JLabel(removeicon);

	JLabel IndividualsDella = new JLabel();

	//---------------------------------------------------------------------------------------------------------------------

	/**
	 * The MemberScreen class constructor.
	 * 
	 */
	public MemberScreen() {
		// Set up all of the Graphical User Interface elements and place them on the screen
		guiInit();
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the layout.
	 * 
	 */
	private void guiInit() {
		this.setLayout(null);
		memberLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		memberLabel.setBorder(BorderFactory.createEtchedBorder());
		memberLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memberLabel.setText("Members");
		memberLabel.setBounds(new Rectangle(0, 0, 657, 20));

		MemberName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		MemberName.setText("Name of someone new (Last, First Middle)");
		MemberName.setBounds(new Rectangle(3, 35, 400, 15));

		MnameTextField.setText("");
		MnameTextField.setBounds(new Rectangle(3, 50, 230, 22));

		InfoAddName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName.setText("To add a name to the list:");
		InfoAddName.setBounds(new Rectangle(3, 75, 240, 15));

		InfoAddName1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName1.setText("1. Click on the box above.");
		InfoAddName1.setBounds(new Rectangle(3, 90, 240, 15));

		InfoAddName2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName2.setText("2. Type the name.");
		InfoAddName2.setBounds(new Rectangle(3, 105, 240, 15));

		InfoAddName3.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddName3.setText("3. Click the ''Add to List'' button.");
		InfoAddName3.setBounds(new Rectangle(3, 120, 240, 15));

		InfoRemoveName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName.setText("To remove a name from the list:");
		InfoRemoveName.setBounds(new Rectangle(3, 140, 240, 15));

		InfoRemoveName1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName1.setText("1. Click on the name to remove.");
		InfoRemoveName1.setBounds(new Rectangle(3, 155, 240, 15));

		InfoRemoveName2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveName2.setText("2. Click the ''Remove from List'' button.");
		InfoRemoveName2.setBounds(new Rectangle(3, 170, 240, 15));

		AddToListButton.setFont(new Font("Dialog", Font.BOLD, 12));
		AddToListButton.setBounds(new Rectangle(240, 70, 170, 30));
		AddToListButton.setText("Add to List ->");
		AddToListButton.addActionListener(AddToListActionListner);

		RemoveFromListButton.setFont(new Font("Dialog", Font.BOLD, 12));
		RemoveFromListButton.setBounds(new Rectangle(240, 120, 170, 30));
		RemoveFromListButton.setText("<- Remove from List");
		RemoveFromListButton.addActionListener(RemoveFromListListener);

		AddAffiliationButton.setFont(new Font("Dialog", Font.BOLD, 12));
		AddAffiliationButton.setBounds(new Rectangle(240, 325, 170, 30));
		AddAffiliationButton.setText("Add affiliation ->");
		AddAffiliationButton.addActionListener(AddAffiliationButtonListener);

		RemoveAffiliationButton.setFont(new Font("Dialog", Font.BOLD, 12));
		RemoveAffiliationButton.setBounds(new Rectangle(240, 375, 170, 30));
		RemoveAffiliationButton.setText("<- Remove affiliation");
		RemoveAffiliationButton.addActionListener(RemoveAffiliationButtonListener);
		
		Instr.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		Instr.setText("<HTML><Body>Click on an individual's name <BR/> "
				+ "to see team affiliation.</BODY></HTML>");
		Instr.setBounds(new Rectangle(240, 160, 240, 40));

		image.setBounds(new Rectangle(260, 220, 170, 30));

		IndividualsDella.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		IndividualsDella.setText("Individuals known by Della");
		IndividualsDella.setBounds(new Rectangle(450, 30, 657, 20));

		IndividualDellaList = new JList(listModel);
		IndividualDellaList.setToolTipText("");
		IndividualDellaList.setBounds(new Rectangle(450, 50, 175, 140));

		InfoAddAffiliation.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAffiliation.setText("To add a team affilation for an individual:");
		InfoAddAffiliation.setBounds(new Rectangle(3, 200, 240, 15));

		InfoAddAffiliation1.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAffiliation1.setText("1. Click on the name of the individual above right.");
		InfoAddAffiliation1.setBounds(new Rectangle(4, 215, 280, 15));

		InfoAddAffiliation2.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAffiliation2.setText("2. Click on a team name in the list below.");
		InfoAddAffiliation2.setBounds(new Rectangle(4, 230, 240, 15));

		InfoAddAffiliation3.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoAddAffiliation3.setText("3. Click on 'Add affiliation' button.");
		InfoAddAffiliation3.setBounds(new Rectangle(4, 245, 240, 15));

		InfoRemoveAffiliation.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		InfoRemoveAffiliation.setText("<HTML><BODY> To remove a team affiliation for an individual: <br/> "
				+ "1. Click on the name of the individual above. <br/> 2. Click on a team name in the list below. <br/> "
				+ "3. Click on ''Remove affiliation'' button.");
		InfoRemoveAffiliation.setBounds(new Rectangle(365, 190, 260, 80));

		AvailableTeam.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		AvailableTeam.setText("Available Teams For");
		AvailableTeam.setBounds(new Rectangle(5, 270, 240, 15));

		AvailableTeamName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		AvailableTeamName.setText("");
		AvailableTeamName.setBounds(new Rectangle(5, 285, 240, 15));

		AvailableTeamList.setToolTipText("");
		AvailableTeamList.setBounds(new Rectangle(5, 300, 175, 140));

		CurrentTeam.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		CurrentTeam.setText("Current Teams For");
		CurrentTeam.setBounds(new Rectangle(450, 270, 240, 15));

		CurrentTeamName.setFont(new java.awt.Font("Dialog", Font.BOLD, 12));
		CurrentTeamName.setText("");
		CurrentTeamName.setBounds(new Rectangle(450, 285, 240, 15));

		CurrentTeamList.setToolTipText("");
		CurrentTeamList.setBounds(new Rectangle(450, 300, 175, 140));

		//----------------------------------------------------------------------------
		// Add the objects to the layout
		this.add(memberLabel);
		this.add(MemberName);	
		this.add(MnameTextField);
		this.add(InfoAddName);
		this.add(InfoAddName1);
		this.add(InfoAddName2);
		this.add(InfoAddName3);
		this.add(InfoRemoveName);
		this.add(InfoRemoveName1);
		this.add(InfoRemoveName2);
		this.add(InfoAddAffiliation);
		this.add(InfoAddAffiliation1);
		this.add(InfoAddAffiliation2);
		this.add(InfoAddAffiliation3);
		this.add(InfoRemoveAffiliation);
		this.add(AddToListButton);
		this.add(RemoveFromListButton);
		this.add(Instr);
		this.add(IndividualsDella);
		this.add(IndividualDellaList);
		this.add(image);
		this.add(AvailableTeam);
		this.add(AvailableTeamName);
		this.add(AvailableTeamList);
		this.add(AddAffiliationButton);
		this.add(RemoveAffiliationButton);
		this.add(CurrentTeam);
		this.add(CurrentTeamName);
		this.add(CurrentTeamList);
		
		IndividualDellaList.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				getAllNameFromRepoTeams();
			}
		});

		AddToListButton.addActionListener(AddToListActionListner);
		RemoveFromListButton.addActionListener(RemoveFromListListener);

		ListSelectionListener listBoxListSelectionListener = new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				AvailableTeamName.setText(IndividualDellaList.getSelectedValue());
				CurrentTeamName.setText(IndividualDellaList.getSelectedValue());
			}
		};
		IndividualDellaList.addListSelectionListener(listBoxListSelectionListener);
		IndividualDellaList.setModel(listModel);
		getAllNameFromRepo();
	}

	private void saveMemberInRepo(String teamName) {
		File file = new File(MEMBERS_REPO);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			FileWriter writer = new FileWriter(file, true);
			writer.write(teamName + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void getAllNameFromRepo() {
		File file = new File(MEMBERS_REPO);
		if (file.exists()) {
			try {
				scanner = new Scanner(file);
				System.out.println(scanner.hasNextLine());
				while (scanner.hasNextLine()) {
					String name = scanner.nextLine();
					listModel.addElement(name);
				}
				scanner.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("File does not exists!");
		}
	}

	private void remove() {
		String memberToRemove = listModel.get(IndividualDellaList.getSelectedIndex());
		listModel.remove(IndividualDellaList.getSelectedIndex());

		File file = new File(MEMBERS_REPO);
		File tempFile = new File("temp_member_repo.txt");

		if (file.exists()) {
			try {
				FileWriter writer = new FileWriter(tempFile);

				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String member = scanner.nextLine();
					if (!member.equals(memberToRemove)) {
						writer.write(member + "\n");
					}
				}
				scanner.close();
				writer.close();
				file.delete();
				tempFile.renameTo(new File(MEMBERS_REPO));
			} 
			catch (Exception e) {}
		}
	}
	
	private void getAllNameFromRepoTeams() {
		avaAFFModel.clear();
		File file = new File(Team_REPO);
		if (file.exists()) {
			try {
				Scanner scanner = new Scanner(file);
				while (scanner.hasNextLine()) {
					String name = scanner.nextLine();
					avaAFFModel.addElement(name);
				}
				scanner.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else {

		}
	}
}
