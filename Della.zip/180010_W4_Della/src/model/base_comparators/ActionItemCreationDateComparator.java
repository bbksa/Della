package model.base_comparators;

import model.ActionItem;

import java.util.Comparator;

public class ActionItemCreationDateComparator implements Comparator<ActionItem> {
    @Override
    public int compare(ActionItem o1, ActionItem o2) {
        return o1.getCreatedDate().compareTo(o2.getCreatedDate());
    }
}
