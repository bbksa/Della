package model.base_comparators;

import model.ActionItem;

import java.util.Comparator;

public class ActionItemDueDateComparator implements Comparator<ActionItem> {
    @Override
    public int compare(ActionItem o1, ActionItem o2) {
        return o1.getDueDate().compareTo(o2.getDueDate());
    }
}
