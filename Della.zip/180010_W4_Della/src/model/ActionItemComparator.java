package model;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ActionItemComparator implements Comparator<ActionItem> {

    private List<Comparator<ActionItem>> listComparators;

    public ActionItemComparator(Comparator<ActionItem>... comparators) {
        this.listComparators = Arrays.asList(comparators);
    }

    @Override
    public int compare(ActionItem o1, ActionItem o2) {
        for (Comparator<ActionItem> comparator: listComparators) {
            int result = comparator.compare(o1, o2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
}
